import sys, os, threading, asyncio, logging, pandas as pd, pandas_ta as ta, json, aiohttp
from kiteconnect import KiteTicker
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.templating import Jinja2Templates
from contextlib import asynccontextmanager
from datetime import datetime
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
import settings

# --- 1. SYSTEM SETUP ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
base_dir = os.path.dirname(os.path.abspath(__file__))
template_path = os.path.join(base_dir, "templates")

# --- 2. GLOBAL STATE ---
ALL_WATCH = list(settings.INDIAN_SYMBOLS.values()) + settings.CRYPTO_SYMBOLS
state = {
    "mode": settings.DEFAULT_MODE,
    "live_prices": {s: 0.0 for s in ALL_WATCH},
    "open_prices": {s: 0.0 for s in ALL_WATCH},
    "total_investment": 0.0, 
    "current_value": 0.0, 
    "total_pnl_combined": 0.0,
    "running_pnl": 0.0, 
    "market_status": "INITIALIZING", 
    "last_update": "00:00:00",
    "trades": [], 
    "dfs": {s: pd.DataFrame() for s in ALL_WATCH}, 
    "active_pos": {}, 
    "targets": {},
    "telegram_status": "Inactive",
    "last_processed_min": {s: -1 for s in ALL_WATCH}
}

# # --- 3. CONNECTION MANAGER ---
# class ConnectionManager:
    # def __init__(self):
        # self.active_connections: list[WebSocket] = []

    # async def connect(self, websocket: WebSocket):
        # await websocket.accept()
        # self.active_connections.append(websocket)

    # def disconnect(self, websocket: WebSocket):
        # if websocket in self.active_connections:
            # self.active_connections.remove(websocket)

    # async def broadcast(self, message: dict):
        # for connection in self.active_connections:
            # try:
                # await connection.send_json(message)
            # except Exception:
                # self.active_connections.remove(connection)

# manager = ConnectionManager()



# --- 3. CONNECTION MANAGER (REINFORCED) ---
class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"New WebSocket connection. Total: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
            logger.info(f"Connection removed. Remaining: {len(self.active_connections)}")

    async def broadcast(self, message: dict):
        # We iterate over a copy [:] to avoid issues if the list changes during broadcast
        for connection in self.active_connections[:]:
            try:
                await connection.send_json(message)
            except Exception:
                # Use the disconnect method which already has the "if in list" check
                self.disconnect(connection)

manager = ConnectionManager()



# --- 4. TELEGRAM & SCHEDULER LOGIC ---
async def send_telegram_msg(msg):
    url = f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": settings.TELEGRAM_CHAT_ID, "text": msg, "parse_mode": "Markdown"}
    async with aiohttp.ClientSession() as sess:
        try:
            async with sess.post(url, json=payload, timeout=10) as resp:
                if resp.status == 200:
                    state["telegram_status"] = "Active"
                else:
                    state["telegram_status"] = "Inactive"
        except:
            state["telegram_status"] = "Inactive"

async def daily_heartbeat():
    """Report at 09:00 AM IST"""
    status = "✅ LIVE" if "LIVE" in state["market_status"] else "⚠️ OFFLINE"
    msg = (f"💓 *FIXSTRA HEARTBEAT*\n"
           f"Status: {status}\n"
           f"Mode: {state['mode']}\n"
           f"Total PnL: ₹{state['total_pnl_combined']}\n"
           f"Active Positions: {len([p for p in state['active_pos'].values() if p])}")
    await send_telegram_msg(msg)

# --- 5. STRATEGY ENGINE ---
async def fetch_history():
    async with aiohttp.ClientSession() as session:
        for sym in settings.CRYPTO_SYMBOLS:
            try:
                url = f"https://api.binance.com/api/v3/klines?symbol={sym}&interval=1m&limit=100"
                async with session.get(url) as resp:
                    data = await resp.json()
                    df = pd.DataFrame(data, columns=['t','O','H','L','Close','V','CT','QV','Tr','BB','BQ','I'])
                    df['Close'] = df['Close'].astype(float)
                    state["dfs"][sym] = df[['Close']].tail(100)
                    state["open_prices"][sym] = df['Close'].iloc[0]
            except Exception as e:
                logger.error(f"History sync fail for {sym}: {e}")

def run_strategy(symbol, price):
    """EMA 5/20 Closing Basis Strategy"""
    df = state["dfs"][symbol] = pd.concat([state["dfs"][symbol], pd.DataFrame([{"Close": price}])]).tail(100)
    if len(df) < 21: return "NEUTRAL"
    
    ema5 = ta.ema(df['Close'], length=5)
    ema20 = ta.ema(df['Close'], length=20)
    
    c_p = df['Close'].iloc[-1]
    c_5, c_20 = ema5.iloc[-1], ema20.iloc[-1]
    p_5, p_20 = ema5.iloc[-2], ema20.iloc[-2]

    # BUY: Cross UP (5 > 20) AND Candle Close > both EMAs
    if p_5 <= p_20 and c_5 > c_20 and c_p > c_5 and c_p > c_20:
        return "BUY"
    
    # SELL: Cross DOWN (5 < 20) AND Candle Close < both EMAs
    if p_5 >= p_20 and c_5 < c_20 and c_p < c_5 and c_p < c_20:
        return "SELL"
    
    return "NEUTRAL"

async def calculate_portfolio():
    """Real-time Combined PnL Calculation"""
    inv, val, unrealized = 0.0, 0.0, 0.0
    for sym, side in state["active_pos"].items():
        if side:
            qty = settings.TRADE_QTY.get(sym, 1)
            entry = state["targets"][sym]["entry"]
            lp = state["live_prices"].get(sym, entry)
            inv += (entry * qty)
            val += (lp * qty)
            # Floating PnL for active trade
            unrealized += (lp - entry) * qty if side == "BUY" else (entry - lp) * qty
            
    state["total_investment"] = round(inv, 2)
    state["current_value"] = round(val, 2)
    state["total_pnl_combined"] = round(state["running_pnl"] + unrealized, 2)

def execute_trade_engine(symbol, price, signal):
    """Exit on 5% SL or 10% TP Only"""
    if state["active_pos"].get(symbol):
        t = state["targets"][symbol]
        side = state["active_pos"][symbol]
        exit_type = None
        
        sl_lvl = t["entry"] * (0.95 if side == "BUY" else 1.05)
        tp_lvl = t["entry"] * (1.10 if side == "BUY" else 0.90)
        
        if (side == "BUY" and price <= sl_lvl) or (side == "SELL" and price >= sl_lvl):
            exit_type = "🚨 SL EXIT"
        elif (side == "BUY" and price >= tp_lvl) or (side == "SELL" and price <= tp_lvl):
            exit_type = "💰 TP EXIT"

        if exit_type:
            pnl = (price - t["entry"]) if side == "BUY" else (t["entry"] - price)
            state["running_pnl"] += pnl
            state["trades"].insert(0, {
                "time": datetime.now().strftime("%H:%M:%S"), 
                "symbol": symbol, "type": exit_type, 
                "entry": t["entry"], "exit": price, "pnl": round(pnl, 2)
            })
            asyncio.create_task(send_telegram_msg(f"{exit_type} | {symbol} Closed @ {price}"))
            state["active_pos"][symbol] = None

    if not state["active_pos"].get(symbol) and signal in ["BUY", "SELL"]:
        state["active_pos"][symbol] = signal
        state["targets"][symbol] = {"entry": price}
        state["trades"].insert(0, {
            "time": datetime.now().strftime("%H:%M:%S"), 
            "symbol": symbol, "type": signal, 
            "entry": price, "exit": "OPEN", "pnl": 0.0
        })
        asyncio.create_task(send_telegram_msg(f"🚀 *NEW TRADE* | {signal} | {symbol} @ {price}"))

# --- 6. BACKGROUND TASKS ---
async def binance_task():
    url = "wss://stream.binance.com:9443/stream?streams=" + "/".join([f"{s.lower()}@ticker" for s in settings.CRYPTO_SYMBOLS])
    while True:
        try:
            async with aiohttp.ClientSession() as sess:
                async with sess.ws_connect(url) as ws:
                    state["market_status"] = "LIVE: BINANCE"
                    async for msg in ws:
                        if state["mode"] != "CRYPTO": break
                        d = json.loads(msg.data)
                        sym = d['stream'].split('@')[0].upper()
                        lp = float(d['data']['c'])
                        state["live_prices"][sym] = lp
                        
                        cur_min = datetime.now().minute
                        if cur_min != state["last_processed_min"][sym]:
                            if state["last_processed_min"][sym] != -1:
                                execute_trade_engine(sym, lp, run_strategy(sym, lp))
                            state["last_processed_min"][sym] = cur_min
                        await calculate_portfolio()
        except:
            state["market_status"] = "RECONNECTING BINANCE..."
            await asyncio.sleep(5)

# --- 7. LIFESPAN & ROUTES ---
@asynccontextmanager
async def lifespan(app: FastAPI):
    # History Sync
    await fetch_history()
    
    # Scheduler Setup (9:00 AM IST)
    scheduler = AsyncIOScheduler(timezone="Asia/Kolkata")
    scheduler.add_job(daily_heartbeat, CronTrigger(hour=9, minute=0))
    scheduler.start()
    
    # Startup Notif
    asyncio.create_task(send_telegram_msg("🚀 *FIXSTRA SYSTEM ONLINE*"))
    
    # UI Broadcast Loop
    async def hb_ui():
        while True:
            state["last_update"] = datetime.now().strftime("%H:%M:%S")
            await manager.broadcast({k: v for k, v in state.items() if k != "dfs"})
            await asyncio.sleep(1)
            
    asyncio.create_task(hb_ui())
    asyncio.create_task(binance_task())
    yield
    scheduler.shutdown()

app = FastAPI(lifespan=lifespan)
templates = Jinja2Templates(directory=template_path)

@app.get("/")
async def index(request: Request):
    return templates.TemplateResponse(request=request, name="index.html")

@app.websocket("/ws")
async def ws_ep(ws: WebSocket):
    await manager.connect(ws)
    try:
        while True: await ws.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(ws)